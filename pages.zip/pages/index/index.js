Page({
  data:{
    indicatorDots:false,
    autoplay:true,
    interval:5000,
    duration:1000,
    imgUrls:[
      "/images/haibao-1.jpg",
      "/images/haibao-2.jpg"
    ],
    goods:[],
  },
  onLoad:function (params) {
    this.loadGoods();
  },
  loadGoods:function (params) {
    var goods=wx.getStorageSync('goods');
    var resule=[];
    for (var i=0;i<goods.length;i++){
      var good=goods[i];
      var type=good.type;
      if(type.indexOf('supermarket')>-1){
        resule.push(good);
      }
    }
    this.setData({goods:resule});
  },
  addGoods:function (e) {
    var goods=wx.getStorageSync('goods');
    var id=e.currentTarget.id;
    var good={};
    for(var i=0;i<goods.length;i++){
      var oldGood=goods[i];
      if(oldGood.id==id){
        good=oldGood;
        break;
      }
    }
    var orders=wx.getStorageSync('orders');
    var addOrders=new Array();
    for(var i=0;i<orders.length;i++){
      var order=orders[i];
      if(order.id==good.id){
        var count=order.count;
        order.count=count+1;
        add=false;
      }
      addOrders[i]=order;
    }
    var len=orders.length;
    if(add){
      good.count=1;
      addOrders[len]=good;
    }
    wx.setStorageSync('orders', addOrders);
    wx.showToast({
      title: '添加成功',
      icon:'success',
      duration:1000
    });
    }
})