Page({

    /**
     * 页面的初始数据
     */
    data: {
list: [
            {id:0,src: 'https://img.alicdn.com/imgextra/i3/6000000004245/O1CN01IUdtb51hEFxRDHfJj_!!6000000004245-0-at.jpg_430x430q90.jpg',title: '洽洽焦糖味瓜子坚果炒货500g*1袋过年休闲零食囤货年货葵花籽恰恰',price:'￥ 47.80',checked:false,num:1},
            {id:1,src: 'https://img.alicdn.com/imgextra/i2/880734502/O1CN018urw0h1j7xp3Y6doG_!!0-item_pic.jpg_430x430q90.jpg',title: '满400减290】三只松鼠夏威夷果160g孕妇零食休闲食品坚果特产',price:'￥ 38.90',checked:false,num:1},
            {id:2,src: 'https://img.alicdn.com/imgextra/i3/628189716/O1CN01O0KzYn2LdyuPhjwBP-628189716.jpg_430x430q90.jpg',title: '满减【百草味-开心果100g】坚果干果孕妇休闲零食原色无漂白袋装',price: ' ￥ 38.70',checked:false,num:2},],
            totalPrice:0,
            all:false
    },
    selected:function(e){
    let idx=e.currentTarget.dataset.idx;
    let temp=this.data.list[idx].checked;
    let dl=this.data.list;
    dl[idx].checked=!temp;
    this.setData({list:dl})
    this.sumPrice();
    },
    selectedAll:function(){
        var that=this;
        let newData=this.data.list;
        let checked=!(this.data.all);
        for(let index=0;index<newData.length;index++)
        {newData[index].checked=checked;}
        this.setData({all:checked,list:newData})
        this.sumPrice();
        
    },
    sumPrice:function(){
        let newData=this.data.list;
        var sum=0.0;
        for(let index=0;index<newData.length;index++){
        if(newData[index].checked==true){
        sum+=(newData[index].num*Number(newData[index].price.substring(2)))}
        }
        this.setData({totalPrice:sum.toFixed(2)})
    },
     GoodsNumChange:function(e){
        let tempList=this.data.list;
        tempList[e.currentTarget.dataset.idx].num=e.detail;
        this.setData({
            list:tempList
        })
        this.sumPrice();
     },
})