Component({
    properties:{
    num:{
        type:Number,
        value:1
    }
    },
    methods:{
        numAdd(){
            let number=this.properties.num+1;
            this.numChange(number);
        },
        numSub(){
            if(this.properties.num<=0){
            wx.showToast({
              title: '数量不能少于0',
              icon:'error',
              duration:1000
            })
            return;
            }else{
                let number=this.properties.num-1;
                this.numChange(number);
            }
        },
        numChange(num){
            this.triggerEvent("goodsNumChange",num);
        }
    }
})